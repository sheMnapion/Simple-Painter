import numpy as np
import cv2 as cv
from line import Line

class Polygon(object):
    """polygon class, supporting draw"""
    def __init__(self,id,points,algorithm,color):
        """store the basical information of a line object"""
        self.id=id
        self.points=points
        self.lines=[]
        for i in range(len(self.points)):
            if i==len(self.points)-1:
                self.lines.append(Line(i,points[i],points[0],algorithm,color))
            else:
                self.lines.append(Line(i,points[i],points[i+1],algorithm,color))
        self.algorithm=algorithm
        self.color=color
    
    def draw(self,pic):
        """draw the polygon on a given picture"""
        for line in self.lines:
            line.draw(pic)